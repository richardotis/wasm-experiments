from . import triangular # register the TriangularAxes
